<?php $__env->startSection('content'); ?>
<?php echo Form::model($quiz ,[
                  'method' => 'PATCH',
                  'route' => ['teacher.quiz.update', $quiz->id],
                ]); ?>


 				<?php echo $__env->make('teacher.quiz.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('teacher.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>