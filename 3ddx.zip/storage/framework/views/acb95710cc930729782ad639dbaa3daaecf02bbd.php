<div>
	<?php if($errors->any()): ?>
	<div class="alert alert-danger">
		<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<p><?php echo e($error); ?></p>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	</div>
	<?php endif; ?>

	<label>Description</label>

	<?php echo Form::text('description'); ?>

		<?php echo Form::select('published', ['0' => 'Not Published', '1' => 'Published']);; ?>

		<p></p>
		<p><button class="add_fields btn btn-primary">Add Question</button></p>
		<div class="wrapper">
			<?php if(!isset($edit)): ?>
			<div class="row">
				<label>Description</label>
				<input required type="text" name="question_description[]" placeholder="Question Description" />
				<label>Possible Answers</label>
				<input required type="text" name="possible_answers[]" placeholder="Possible Answers" />
				<label>Correct Answer</label>
				<input required type="text" name="correct_answer[]" placeholder="Correct Answer" />
				<label>Explanation</label>
				<input required type="text" name="explanation[]" placeholder="Explanation" />
				<a href="javascript:void(0);" class="remove_field">Remove</a>
			</div>
			<?php else: ?>
			<?php $__currentLoopData = $quiz->questions()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="row">
					<label>Description</label>
					<input value="<?php echo e($question->question_description); ?>" required type="text" name="question_description[]" placeholder="Question Description" />
					<label>Possible Answers</label>
					<input value="<?php echo e($question->possible_answers); ?>" required type="text" name="possible_answers[]" placeholder="Possible Answers" />
					<label>Correct Answer</label>
					<input value="<?php echo e($question->correct_answer); ?>" required type="text" name="correct_answer[]" placeholder="Correct Answer" />
					<label>Explanation</label>
					<input value="<?php echo e($question->explanation); ?>" required type="text" name="explanation[]" placeholder="Explanation" />
					<a href="javascript:void(0);" class="remove_field">Remove</a>
				</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php endif; ?>
		</div>
		
		<input type="submit" value="Submit">
	</div>

<script>
//Add Input Fields
$(document).ready(function() {
    var max_fields = 10; //Maximum allowed input fields 
    var wrapper    = $(".wrapper"); //Input fields wrapper
    var add_button = $(".add_fields"); //Add button class or ID
    var x = 1; //Initial input field is set to 1

 //When user click on add input button
 $(add_button).click(function(e){
 	e.preventDefault();
 //Check maximum allowed input fields
 if(x < max_fields){ 
            x++; //input field increment
 //add input field
 $(wrapper).append('<div class="row"> <label>Description</label> <input required type="text" name="question_description[]" placeholder="Question Description" /> <label>Possible Answers</label> <input required type="text" name="possible_answers[]" placeholder="Possible Answers" /> <label>Correct Answer</label> <input required type="text" name="correct_answer[]" placeholder="Correct Answer" /> <label>Explanation</label> <input required type="text" name="explanation[]" placeholder="Explanation" /> <a href="javascript:void(0);" class="remove_field">Remove</a> </div>');
}
});
 
    //when user click on remove button
    $(wrapper).on("click",".remove_field", function(e){ 
    	e.preventDefault();
 $(this).parent('div').remove(); //remove inout field
 x--; //inout field decrement
})
});
</script>