<?php $__env->startSection('content'); ?>
 <table id="mytable" class="table table-bordred table-striped">
                   
                   <thead>
                   
                   <th>Description</th>
                      <th>Edit</th>
                       <th>Delete</th>
                   </thead>
 <tbody>
    <?php $__currentLoopData = $quizzes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
    <td><?php echo e($quiz->description); ?></td>
    <td><p title="Edit"><a href="<?php echo e(route('teacher.quiz.edit',$quiz->id)); ?>" class="btn btn-primary btn-xs"  ><span class="glyphicon glyphicon-pencil"></span></a></p></td>
    <td><p title="Delete"><button class="btn btn-danger btn-xs" data-title="Delete" data-toggle="modal" data-target="#delete<?php echo e($quiz->id); ?>" ><span class="glyphicon glyphicon-trash"></span></button></p></td>
    </tr>
    <!-- Modal content-->
    <div class="modal fade" id="delete<?php echo e($quiz->id); ?>" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Confirm Deletion</h4>
        </div>
        <div class="modal-body">
          <p>You will permenantly delete this quiz.</p>
        </div>
        <div class="modal-footer">
          <a href="<?php echo e(route('teacher.quiz.delete',$quiz->id)); ?>" type="button" class="btn btn-danger" >Confirm</a>
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      </div>
  </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
<script type="text/javascript">
	
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('teacher.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>